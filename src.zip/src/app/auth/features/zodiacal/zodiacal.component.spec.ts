import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZodiacalComponent } from './zodiacal.component';

describe('ZodiacalComponent', () => {
  let component: ZodiacalComponent;
  let fixture: ComponentFixture<ZodiacalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ZodiacalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ZodiacalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
