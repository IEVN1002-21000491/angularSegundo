import { Component } from '@angular/core';

@Component({
  selector: 'app-sing-up',
  standalone: true,
  imports: [],
  templateUrl: './sing-up.component.html',
  styles: ``
})
export default class SingUpComponent {
  
}
