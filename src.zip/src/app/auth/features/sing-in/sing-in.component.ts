import { Component } from '@angular/core';

@Component({
  selector: 'app-sing-in',
  standalone: true,
  imports: [],
  templateUrl: './sing-in.component.html',
  styles: ``
})
export default class SingInComponent {

}
