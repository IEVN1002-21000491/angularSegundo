import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface Signos {
  nombre: string;
  apaterno: string;
  amaterno: string;
  dia: number;
  mes: number;
  year: number;
  sexo: string;
}

@Component({
  selector: 'app-zodiaco',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './zodiaco.component.html',
  styleUrls: ['./zodiaco.component.css']
})
export class ZodiacoComponent implements OnInit {
  formGroup!: FormGroup;
  clientes: Signos = {
    nombre: '',
    apaterno: '',
    amaterno: '',
    dia: 0,
    mes: 0,
    year: 0,
    sexo: '',
  };

  constructor(private fb: FormBuilder, private router: Router) {}

  ngOnInit(): void {
    this.formGroup = this.initForm();

    // Suscribirse a los cambios del formulario
    this.formGroup.valueChanges.subscribe(() => {
      this.actualizarInfoCliente();
    });
  }

  initForm(): FormGroup {
    return this.fb.group({
      nombre: [''],
      apaterno: [''],
      amaterno: [''],
      dia: [''],
      mes: [''],
      year: [''],
      sexo: ['']
    });
  }

  actualizarInfoCliente(): void {
    const { nombre, apaterno, amaterno, dia, mes, year, sexo } = this.formGroup.value;
    
    this.clientes.nombre = nombre;
    this.clientes.apaterno = apaterno;
    this.clientes.amaterno = amaterno;
    this.clientes.dia = dia;
    this.clientes.mes = mes;
    this.clientes.year = year;
    this.clientes.sexo = sexo;

    // Actualizar los datos en localStorage cada vez que el formulario cambia
    localStorage.setItem('clienteInfo', JSON.stringify(this.clientes));
  }

  onSubmit(): void {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['/auth/zodiacal']);
  }
}
